// Nút nổi "Thêm vào Fshare Auto Download" trên trang thư mục Fshare
(function () {
  if (document.getElementById("fad-add-btn")) return;
  const btn = document.createElement("button");
  btn.id = "fad-add-btn";
  btn.type = "button";
  btn.innerHTML = '<span class="fad-ic">⬇</span><span class="fad-tx">Thêm vào Fshare Auto Download</span>';
  btn.title = "Thêm thư mục Fshare này vào tool Fshare Auto Download";
  btn.addEventListener("click", async () => {
    btn.disabled = true;
    btn.querySelector(".fad-tx").textContent = "Đang thêm...";
    const r = await browser.runtime.sendMessage({ type: "addFolder", url: location.href });
    btn.classList.toggle("fad-ok", !!(r && r.ok));
    btn.classList.toggle("fad-err", !(r && r.ok));
    btn.querySelector(".fad-tx").textContent = r && r.ok ? "✔ Đã thêm vào tool" : "⚠ " + ((r && r.error) || "Lỗi");
    setTimeout(() => {
      btn.disabled = false;
      btn.classList.remove("fad-ok", "fad-err");
      btn.querySelector(".fad-tx").textContent = "Thêm vào Fshare Auto Download";
    }, 4000);
  });
  document.body.appendChild(btn);
})();
