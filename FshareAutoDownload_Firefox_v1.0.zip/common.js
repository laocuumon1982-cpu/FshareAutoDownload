// Dùng chung cho nền, bảng bật lên và trang cài đặt
const DEFAULTS = { server: "http://127.0.0.1:8080", pin: "", notify: true };

async function getCfg() {
  const c = await browser.storage.local.get(DEFAULTS);
  c.server = String(c.server || DEFAULTS.server).trim().replace(/\/+$/, "");
  if (!/^https?:\/\//i.test(c.server)) c.server = "http://" + c.server;
  return c;
}

// Gọi API của tool trên máy tính. Lỗi -> ném Error có thông báo tiếng Việt.
async function callApi(path, body) {
  const cfg = await getCfg();
  let r;
  try {
    r = await fetch(cfg.server + path, {
      method: body ? "POST" : "GET",
      headers: { "Content-Type": "application/json", "X-Pin": cfg.pin || "" },
      body: body ? JSON.stringify(body) : undefined,
      cache: "no-store",
    });
  } catch (e) {
    const err = new Error("Không kết nối được tool. Tool đã mở chưa? Địa chỉ: " + cfg.server);
    err.offline = true;
    throw err;
  }
  let j = {};
  try { j = await r.json(); } catch (e) {}
  if (r.status === 401) {
    const err = new Error("Sai hoặc thiếu mã PIN (đặt trong Cài đặt của tiện ích).");
    err.auth = true;
    throw err;
  }
  if (!r.ok) throw new Error(j.error || "Lỗi " + r.status);
  return j;
}

function folderCodeFromUrl(url) {
  const m = String(url || "").match(/fshare\.vn\/folder\/([A-Za-z0-9]+)/);
  return m ? m[1] : "";
}
