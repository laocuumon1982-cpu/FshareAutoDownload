// Nền: cập nhật số tập mới trên biểu tượng, thông báo, menu chuột phải, chuyển tiếp lệnh từ trang Fshare.
let last = null; // trạng thái lần trước để so sánh

async function poll() {
  try {
    const s = await callApi("/api/state");
    const n = s.stats.new || 0;
    browser.browserAction.setBadgeText({ text: n ? String(n) : (s.busy ? "…" : "") });
    browser.browserAction.setBadgeBackgroundColor({ color: s.busy ? "#d97706" : "#dc2626" });
    browser.browserAction.setTitle({
      title: `Fshare Auto Download ${s.version}\n${n} file mới · ${s.stats.dl} đang tải · ${s.stats.owned} đã có` +
             (s.auto ? `\nTự quét: lần tới ${s.next}` : "\nTự quét: tắt"),
    });
    const cfg = await getCfg();
    if (cfg.notify && last) {
      if (s.summary && s.summary !== last.summary && n > 0) {
        notify("Có " + n + " file mới", s.summary);
      }
      if (s.stats.dl < last.stats.dl && s.stats.owned >= last.stats.owned) {
        const k = last.stats.dl - s.stats.dl;
        notify("Tải xong " + k + " file", "Mở tiện ích để xem chi tiết.");
      }
    }
    last = s;
  } catch (e) {
    browser.browserAction.setBadgeText({ text: e.auth ? "PIN" : "!" });
    browser.browserAction.setBadgeBackgroundColor({ color: "#6b7280" });
    browser.browserAction.setTitle({ title: "Fshare Auto Download\n" + e.message });
  }
}

function notify(title, message) {
  browser.notifications.create({
    type: "basic", iconUrl: "icons/icon96.png", title: title, message: message || "",
  });
}

async function addFolder(url) {
  const code = folderCodeFromUrl(url);
  if (!code) {
    notify("Không phải link thư mục Fshare", "Chỉ thêm được link dạng fshare.vn/folder/...");
    return { ok: false, error: "Không phải link thư mục Fshare" };
  }
  try {
    await callApi("/api/folders/add", { url: "https://www.fshare.vn/folder/" + code });
    notify("Đã thêm thư mục", "Vào tool / tiện ích → Thư mục → \"Quét file\" để chọn file đã có.");
    poll();
    return { ok: true };
  } catch (e) {
    notify("Chưa thêm được thư mục", e.message);
    return { ok: false, error: e.message };
  }
}

// Menu chuột phải trên trang / link thư mục Fshare
browser.contextMenus.create({
  id: "fad-add-link", title: "Thêm vào Fshare Auto Download",
  contexts: ["link"], targetUrlPatterns: ["*://*.fshare.vn/folder/*"],
});
browser.contextMenus.create({
  id: "fad-add-page", title: "Thêm thư mục này vào Fshare Auto Download",
  contexts: ["page"], documentUrlPatterns: ["*://*.fshare.vn/folder/*"],
});
browser.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "fad-add-link") addFolder(info.linkUrl);
  if (info.menuItemId === "fad-add-page") addFolder(info.pageUrl || (tab && tab.url));
});

// Lệnh từ bảng bật lên / nút trên trang Fshare
browser.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "addFolder") return addFolder(msg.url);
  if (msg && msg.type === "poll") return poll().then(() => ({ ok: true }));
  if (msg && msg.type === "api") {
    return callApi(msg.path, msg.body).then(
      (r) => ({ ok: true, data: r }),
      (e) => ({ ok: false, error: e.message, auth: !!e.auth, offline: !!e.offline })
    );
  }
});

browser.alarms.create("poll", { periodInMinutes: 1 });
browser.alarms.onAlarm.addListener((a) => { if (a.name === "poll") poll(); });
browser.storage.onChanged.addListener(() => { last = null; poll(); });
poll();
