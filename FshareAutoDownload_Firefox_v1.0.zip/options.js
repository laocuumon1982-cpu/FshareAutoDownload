const $ = (s) => document.querySelector(s);

(async () => {
  const c = await getCfg();
  $("#server").value = c.server;
  $("#pin").value = c.pin;
  $("#notify").checked = c.notify;
})();

$("#save").onclick = async () => {
  await browser.storage.local.set({
    server: $("#server").value.trim() || DEFAULTS.server,
    pin: $("#pin").value,
    notify: $("#notify").checked,
  });
  const m = $("#msg");
  m.className = ""; m.textContent = "Đang kiểm tra kết nối...";
  try {
    const s = await callApi("/api/state");
    m.className = "ok";
    m.textContent = `✔ Kết nối OK — ${s.app} ${s.version} · ${s.stats.folders} thư mục · ${s.stats.owned} file đã có`;
  } catch (e) {
    m.className = "err";
    m.textContent = "✘ " + e.message;
  }
};
