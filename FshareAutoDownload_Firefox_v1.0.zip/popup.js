const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let rows = [], sel = new Set(), seen = new Set(), busy = false, ver = {};

async function api(path, body) {
  const r = await browser.runtime.sendMessage({ type: "api", path, body });
  if (!r || !r.ok) {
    const e = new Error((r && r.error) || "Lỗi");
    e.offline = r && (r.offline || r.auth);
    throw e;
  }
  return r.data;
}
function toast(t) { const e = $("#toast"); e.textContent = t; e.classList.add("on"); clearTimeout(e._t); e._t = setTimeout(() => e.classList.remove("on"), 2400); }
async function act(fn, ok) { try { const r = await fn(); if (ok) toast(typeof ok === "function" ? ok(r) : ok); return r; } catch (e) { toast("⚠ " + e.message); } }

async function refresh(force) {
  let s;
  try { s = await api("/api/state"); }
  catch (e) {
    $("#main").classList.add("hide"); $("#offline").classList.remove("hide");
    $("#off-msg").textContent = e.message; $("#ver").textContent = "Chưa kết nối"; return;
  }
  $("#offline").classList.add("hide"); $("#main").classList.remove("hide");
  busy = s.busy;
  $("#ver").textContent = s.version + (s.busy ? " · đang chạy..." : "");
  $("#s-new").textContent = s.stats.new; $("#s-dl").textContent = s.stats.dl;
  $("#s-owned").textContent = s.stats.owned; $("#s-folders").textContent = s.stats.folders;
  $("#status").textContent = s.status || ""; $("#status").title = s.status || "";
  $("#prog").style.width = (s.progress[1] ? Math.min(100, 100 * s.progress[0] / s.progress[1]) : 0) + "%";
  $("#btn-scan").disabled = $("#btn-go").disabled = s.busy; $("#btn-stop").disabled = !s.busy;
  if (document.activeElement !== $("#interval")) { $("#auto").checked = s.auto; $("#interval").value = String(s.interval); }
  $("#auto-info").textContent = s.auto ? "Lần tới: " + (s.next || "--") : "Đang tắt";
  const u = $("#unrev");
  u.classList.toggle("hide", !s.stats.unreviewed);
  u.textContent = s.stats.unreviewed ? `◔ ${s.stats.unreviewed} thư mục chưa duyệt — mở trang đầy đủ (⤢) → Thư mục → "Quét file".` : "";
  $("#summary").textContent = s.summary ? "Quét lần cuối: " + s.summary : "";
  if (force || s.ver.rows !== ver.rows) await loadRows();
  ver = s.ver; updSel();
}

async function loadRows() {
  rows = await api("/api/rows");
  const codes = new Set(rows.map((r) => r.code));
  if (!rows.length) { sel.clear(); seen.clear(); }
  rows.forEach((r) => { if (!seen.has(r.code)) { seen.add(r.code); if (r.tag === "new") sel.add(r.code); } });
  [...sel].forEach((c) => { if (!codes.has(c)) sel.delete(c); });
  render();
}
function render() {
  $("#cnt").textContent = rows.length ? `(${rows.length})` : "";
  $("#rows").innerHTML = rows.length ? rows.map((r) => `<div class="it" data-c="${r.code}">
    <div class="chk ${sel.has(r.code) ? "on" : ""}">${sel.has(r.code) ? "✓" : ""}</div>
    <div class="grow"><div class="nm">${esc(r.name)}</div><div class="sub">${esc(r.folder)}${r.note ? " · " + esc(r.note) : ""} · ${esc(r.size)}</div>
    <div class="st ${r.tag}">${esc(r.status)}</div></div></div>`).join("")
    : '<div class="empty">Chưa có kết quả. Bấm "⌕ Quét" để tìm file mới.</div>';
  $("#rows").querySelectorAll(".it").forEach((e) => (e.onclick = () => { const c = e.dataset.c; sel.has(c) ? sel.delete(c) : sel.add(c); render(); }));
  updSel();
}
function updSel() {
  const n = sel.size;
  $("#btn-dl").disabled = $("#btn-mark").disabled = !n || busy;
  $("#btn-dl").textContent = n ? `⬇ Tải ${n} file` : "⬇ Tải mục đã chọn";
}

$("#sel-all").onclick = (e) => { e.preventDefault(); rows.forEach((r) => sel.add(r.code)); render(); };
$("#sel-none").onclick = (e) => { e.preventDefault(); sel.clear(); render(); };
const scan = (dl) => act(() => api("/api/scan", { download: dl }), dl ? "Đang quét & tải..." : "Đang quét...")
  .then((r) => { if (r) { sel.clear(); seen.clear(); setTimeout(() => refresh(true), 700); } });
$("#btn-scan").onclick = () => scan(false);
$("#btn-go").onclick = () => scan(true);
$("#btn-stop").onclick = () => act(() => api("/api/stop", {}), "Đã yêu cầu dừng");
$("#btn-dl").onclick = () => act(() => api("/api/download", { codes: [...sel] }), (r) => "Đang tải " + r.count + " file").then(() => setTimeout(() => refresh(true), 700));
$("#btn-mark").onclick = () => act(() => api("/api/mark", { codes: [...sel] }), "Đã thêm vào Danh sách đã có").then(() => { sel.clear(); refresh(true); });
$("#auto").onchange = $("#interval").onchange = () =>
  act(() => api("/api/auto", { on: $("#auto").checked, interval: +$("#interval").value }), $("#auto").checked ? "Đã bật tự quét" : "Đã tắt tự quét").then(() => refresh(false));
$("#open-opt").onclick = $("#off-opt").onclick = () => { browser.runtime.openOptionsPage(); window.close(); };
$("#off-retry").onclick = () => refresh(true);
$("#open-full").onclick = async () => { const c = await getCfg(); browser.tabs.create({ url: c.server + "/" }); window.close(); };

refresh(true);
setInterval(() => refresh(false), 2500);
browser.runtime.sendMessage({ type: "poll" });
